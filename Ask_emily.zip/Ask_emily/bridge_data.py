import json

def fetch_bridge_data():
    # Simulated static bridge data stored locally
    bridge_data = [
        { "id": 1, "name": "Golden Gate Bridge", "height": "67", "coordinates": [37.8199, -122.4783] },
        { "id": 2, "name": "Brooklyn Bridge", "height": "41", "coordinates": [40.7061, -73.9969] }
    ]
    return bridge_data
